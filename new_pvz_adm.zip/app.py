from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os
from config import Config
from models import db, User, Employee, Shift
from data_manager import allowed_file, import_excel

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.before_first_request
def create_tables():
    db.create_all()
    if not User.query.filter_by(username="admin").first():
        user = User(username="admin", password=generate_password_hash("12345"))
        db.session.add(user)
        db.session.commit()

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for("dashboard"))
        flash("Неверные данные")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.route("/", methods=["GET", "POST"])
@login_required
def dashboard():
    if request.method == "POST":
        file = request.files.get("file")
        if file and allowed_file(file.filename):
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
            file.save(filepath)
            import_excel(filepath)
            flash("Файл успешно загружен и обработан")
            return redirect(url_for("dashboard"))

    employees = Employee.query.all()
    shifts = Shift.query.order_by(Shift.date).all()
    return render_template("dashboard.html", employees=employees, shifts=shifts)

@app.route("/analytics")
@login_required
def analytics():
    # Заготовка для аналитики WB/Яндекс
    shifts = Shift.query.all()
    data = {}
    for s in shifts:
        name = s.employee.name
        data[name] = data.get(name, 0) + s.hours
    return render_template("analytics.html", data=data)

@app.route("/charts")
@login_required
def charts():
    shifts = Shift.query.all()
    chart_data = {}
    for s in shifts:
        name = s.employee.name
        chart_data[name] = chart_data.get(name, 0) + s.hours
    return render_template("charts.html", chart_data=chart_data)

@app.route("/employees")
@login_required
def employees_page():
    employees = Employee.query.all()
    return render_template("employees.html", employees=employees)

if __name__ == "__main__":
    app.run(debug=True)